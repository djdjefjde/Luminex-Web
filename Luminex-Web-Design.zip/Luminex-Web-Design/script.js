// Luminex Web Design
console.log("Sitio cargado correctamente.");